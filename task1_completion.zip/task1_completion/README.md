\# Project Title



**01\_my\_first\_analysis**





\## Description



**My first python program to test currencies data in cryptocurrency dataset.**





\## Getting Started



**✅ Install Python and see it work**

**✅ Load real currency data**

**✅ See 79 currencies in a table**

**✅ Create your first bar chart (Top 10 currencies)**





\### Installing



Step 1: Install Anaconda (Anaconda = Python + Everything you need in one package)



Step 2: Launch Jupyter Notebook (Jupyter = Where you'll write code)



Step 3: Create Your Project in Jupyter Notebook



Step 4: Download the 4 json files and upload it to jupyter.



Step 5: Upload the project file and run the code in jupyter notebook.







\### My First-Task Summary



✅ Installed Python and Jupyter Notebook

✅ Loaded real currency data

✅ Saw the currency data in tables

✅ Created my first bar-chart visualization

✅ Calculated basic statistics

